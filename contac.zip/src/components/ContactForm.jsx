// src/components/ContactForm.jsx
import React, { useState } from "react";
import styles from "../css/ContactForm.module.css";
import ActionPanel from "./form/Actionpanel";
import FileUpload from "./form/Fileupload";

function ContactForm() {
  const [mode, setMode] = useState("contacto"); // "contacto" o "queja"
  const [formData, setFormData] = useState({
    nombre: "",
    correo: "",
    telefono: "",
    categoria: "consulta",
    asunto: "",
    mensaje: "",
    adjunto: null,
  });

  const [fileVisible, setFileVisible] = useState(false); // controla FileUpload

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files) setFormData({ ...formData, [name]: files[0] });
    else setFormData({ ...formData, [name]: value });
  };

  const handleFileSelect = (file) => {
    setFormData({ ...formData, adjunto: file });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Datos enviados:", formData);
    alert("Formulario enviado con éxito 🚀");
  };

  const handleClear = () => {
    setFormData({
      nombre: "",
      correo: "",
      telefono: "",
      categoria: "consulta",
      asunto: "",
      mensaje: "",
      adjunto: null,
    });
    setFileVisible(false); // opcional: esconder FileUpload al limpiar
  };

  const handleAttachClick = () => setFileVisible(!fileVisible); // alterna FileUpload

  const getInfoText = (targetMode) => {
    if (targetMode === "contacto")
      return "Formulario de Queja/Sugerencia oculto. Aquí puedes enviar consultas generales.";
    if (targetMode === "queja")
      return "Formulario de Contacto oculto. Aquí puedes enviar quejas o sugerencias.";
  };

  // Función para renderizar inputs con la clase wave-group
  const renderInput = ({ type, name, placeholder, required }) => (
    <div className={styles["wave-group"]}>
      <input
        className={styles.input}
        type={type}
        name={name}
        value={formData[name]}
        onChange={handleChange}
        required={required}
      />
      <span className={styles.label}>
        {[...placeholder].map((char, idx) => (
          <span
            key={idx}
            className={styles["label-char"]}
            style={{ "--index": idx }}
          >
            {char}
          </span>
        ))}
      </span>
      <span className={styles.bar}></span>
    </div>
  );

  return (
    <div className={styles.contactContainer}>
      {/* Panel horizontal con iconos */}
      <ActionPanel
        mode={mode}
        setMode={setMode}
        onClear={handleClear}
        onAttach={handleAttachClick} // llama FileUpload
      />

      {/* Renderiza FileUpload si fileVisible es true */}
      <FileUpload visible={fileVisible} onFileSelect={handleFileSelect} />

      {/* Layout de formularios con animación */}
      <div className={styles.formsWrapper}>
        {/* Columna izquierda */}
        <div className={styles.formColumn}>
          <div
            className={`${styles.infoMessage} ${
              mode === "contacto" ? styles.hidden : styles.visible
            }`}
          >
            {getInfoText("contacto")}
          </div>
          <form
            className={`${styles.formHalf} ${
              mode === "contacto" ? styles.visible : styles.hidden
            }`}
            onSubmit={handleSubmit}
          >
            {renderInput({ type: "text", name: "nombre", placeholder: "Nombre", required: true })}
            {renderInput({ type: "email", name: "correo", placeholder: "Correo", required: true })}
            {renderInput({ type: "text", name: "telefono", placeholder: "Teléfono", required: false })}
            {renderInput({ type: "text", name: "asunto", placeholder: "Asunto", required: false })}
            <div className={styles["wave-group"]}>
              <textarea
                className={styles.input}
                name="mensaje"
                placeholder="Mensaje"
                value={formData.mensaje}
                onChange={handleChange}
                required
              />
              <span className={styles.bar}></span>
            </div>
            <button type="submit" className={styles.button}>
              Enviar
            </button>
          </form>
        </div>

        {/* Columna derecha */}
        <div className={styles.formColumn}>
          <div
            className={`${styles.infoMessage} ${
              mode === "queja" ? styles.hidden : styles.visible
            }`}
          >
            {getInfoText("queja")}
          </div>
          <form
            className={`${styles.formHalf} ${
              mode === "queja" ? styles.visible : styles.hidden
            }`}
            onSubmit={handleSubmit}
          >
            {renderInput({ type: "text", name: "nombre", placeholder: "Nombre", required: true })}
            {renderInput({ type: "email", name: "correo", placeholder: "Correo", required: true })}
            <div className={styles["wave-group"]}>
              <select
                className={styles.input}
                name="categoria"
                value={formData.categoria}
                onChange={handleChange}
                required
              >
                <option value="queja">Queja</option>
                <option value="sugerencia">Sugerencia</option>
              </select>
              <span className={styles.bar}></span>
            </div>
            <div className={styles["wave-group"]}>
              <textarea
                className={styles.input}
                name="mensaje"
                placeholder="Mensaje"
                value={formData.mensaje}
                onChange={handleChange}
                required
              />
              <span className={styles.bar}></span>
            </div>
            <button type="submit" className={styles.button}>
              Enviar
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ContactForm;
