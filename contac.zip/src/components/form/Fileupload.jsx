// src/components/FileUpload.jsx
import React, { useState } from "react";
import styles from "../../css/FileUpload.module.css";

function FileUpload({ onFileSelect, visible }) {
  const [fileName, setFileName] = useState("");

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileName(file.name);
      onFileSelect && onFileSelect(file);
    }
  };

  if (!visible) return null; // solo mostrar si visible=true

  return (
    <div className={styles.container}>
      <div className={styles.folder}>
        <div className={styles["front-side"]}>
          <div className={styles.tip}></div>
          <div className={styles.cover}></div>
        </div>
        <div className={styles["back-side"] + " " + styles.cover}></div>
      </div>
      <label className={styles["custom-file-upload"]}>
        <input type="file" onChange={handleFileChange} />
        {fileName ? fileName : "Choose a file"}
      </label>
    </div>
  );
}

export default FileUpload;
